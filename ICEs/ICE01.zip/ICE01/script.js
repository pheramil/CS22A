/*global $ */
// We need to add the line above to get rid of the following error: '$' was used beofre it was defined.

// Shawn Chumbar
$("#content").append("<strong>JavaScript is working!</strong>");